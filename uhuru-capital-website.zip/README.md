# Uhuru Capital Website

**Slogan:** Financial Freedom Begins With Knowledge

## 🎯 Project Mission

Uhuru Capital is a community-driven educational platform focused on introducing people of color and underserved populations around the world to the world of Bitcoin. We simplify Bitcoin through interactive learning, engaging flashcards, dynamic games, and creative challenges. Our goal is to make financial freedom accessible, enjoyable, and empowering.

## 📚 What's Inside

- Interactive Bitcoin learning dashboard
- Clickable intro video powered by Uhuru Capital logo
- Merch store to fund education & reinvest in Bitcoin
- Smart user form filtering for personalized learning
- Fully open-source under the MIT License

## 🚀 How to Contribute

1. Clone the repo
2. Modify or expand components (HTML/CSS/JS)
3. Share in your own community or remix it for your needs
4. Submit pull requests or feedback!

## 🌐 Live Preview

Once deployed via GitHub Pages:  
`https://<your-username>.github.io/uhuru-capital-website`

## 📜 License

This project is licensed under the MIT License. See [LICENSE](LICENSE) for details.
